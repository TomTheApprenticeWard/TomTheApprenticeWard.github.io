windstorm={
	day_timer=0,
	currtime=0,
	timer=1,
	storm={},
	storm_chance=1800,
	storm_chance_end=50,
  item_age=tonumber(minetest.settings:get("item_entity_ttl")),
}

dofile(minetest.get_modpath("windstorm") .. "/items.lua")

minetest.register_on_joinplayer(function(player)		-- set sky for joining players
	windstorm.daycircle(player)
end)

-- TODO: use the function minetest.after instead
--  it can be called far less frequently than minetest.register_globalstep
minetest.register_globalstep(function(dtime)		-- set sky for players
	windstorm.day_timer=windstorm.day_timer+dtime
	if windstorm.day_timer<windstorm.timer then return end
	windstorm.day_timer=0
	windstorm.daycircle()
end)

windstorm.daycircle=function(join)			--set sky color and clouds
						--[joined player] [time changed by command] [evening or night] [night or morning]
						--evening and morning = set timer to 0.2, else 1
	local d=minetest.get_timeofday()
	windstorm.weather(d)
	if join or (d-0.1>windstorm.currtime or d+0.1<windstorm.currtime) or (d>=0.75 and d<0.81) or (d>0.19 and d<0.26) then
		windstorm.currtime=d
		local t=1
		if d>=0.75 and d<0.8 then
			t=(0.8-d)*20
			windstorm.timer=0.33
		elseif d>0.8 or d<0.2 then
			t=0
			windstorm.timer=1
		elseif d>=0.2 and d<0.25 then
			t=(-0.2+d)*20
			windstorm.timer=0.3
		elseif d>0.25 then
			t=1
			windstorm.timer=1
		end
		if join then
--			join:set_sky({r=255*t, g=240*t, b=170*t},"plain",{})
--			join:set_clouds({
--				color={r=255, g=240, b=70, a=200*t},
--				ambient={r=255, g=255, b=170, a=100},
--				density=0.5,
--				height=200,
--				speed=-40
--			})
			return
		end
		for _,player in ipairs(minetest.get_connected_players()) do
--			player:set_sky({r=255*t, g=240*t, b=170*t},"plain",{})
--			player:set_clouds({
--				color={r=255, g=240, b=70, a=200*t},
--				ambient={r=255, g=255, b=170, a=100},
--				density=0.5,
--				height=200,
--				speed=-40
--			})
		end
	else
		windstorm.timer=1
	end
	windstorm.currtime=d
end

windstorm.weather=function(d)
	if not windstorm.storm.dir and math.random(1,windstorm.storm_chance)==1 then
		local d={{x=1,z=0},{x=-1,z=0},{x=0,z=1},{x=0,z=-1}}
		local max
		local min
		d=d[math.random(1,4)]
		if d.x==1 then
			max={x=-15,z=15}
			min={x=-15,z=-15}
		elseif d.x==-1 then
			max={x=15,z=15}
			min={x=15,z=-15}
		elseif d.z==1 then
			max={x=15,z=-15}
			min={x=-15,z=-15}
		else --if d.z==-1 then
			max={x=15,z=15}
			min={x=-15,z=15}
		end
		windstorm.storm.max=max
		windstorm.storm.min=min
		windstorm.storm.dir=d
	elseif windstorm.storm.dir then
		if math.random(1,windstorm.storm_chance_end)==1 then
			windstorm.storm={}
			return
		end
		local d=windstorm.storm.dir
		local max=windstorm.storm.max
		local min=windstorm.storm.min
		for _,player in ipairs(minetest.get_connected_players()) do
			local pos=player:get_pos()
			local l=minetest.get_node_light(pos)
      local yPos=pos.y+math.random(1,10)
      -- make sure the position to spawn the duster is above sea level
      if (yPos<1) then
        break
      end
			if l and l>=default.LIGHT_MAX-1 then
				windstorm.new_dust=1
				local e=minetest.add_entity({x=pos.x+math.random(min.x,max.x),y=yPos, z=pos.z+math.random(min.z,max.z)}, "windstorm:duster")
				e:set_velocity({x=windstorm.storm.dir.x*5, y=-2, z=windstorm.storm.dir.z*5})
				e:set_acceleration({x=windstorm.storm.dir.x*5, y=-2, z=windstorm.storm.dir.z*5})
				windstorm.new_dust=nil
				local pos3={x=pos.x+max.x, y=pos.y+5, z=pos.z+max.z}
				minetest.add_particlespawner({
					amount = 20,
					time=2,
					maxpos = {x=pos.x+min.x, y=pos.y, z=pos.z+min.z},
					minpos = pos3,
					minvel = {x=d.x*10, y=-1, z=d.z*10},
					maxvel = {x=d.x*20, y=0.5, z=d.z*20},
					minacc = {x=d.x*5, y=-1, z=d.z*5},
					maxacc = {x=d.x*10, y=-10, z=d.z*10},
					minexptime = 0.5,
					maxexptime = 2,
					minsize = 0.8,
					maxsize = 1.3,
					texture = "default_dirt.png",
					collisiondetection=true,
				})
				windstorm.new_dust=1
				for i, ob in pairs(minetest.get_objects_inside_radius(pos, 20)) do
					if ob:get_luaentity() and not ob:get_luaentity().dust and windstorm.visibility(ob:get_pos(),pos3) then
						if ob:get_luaentity().itemstring then
							ob:get_luaentity().age=windstorm.item_age
						end
						minetest.add_entity(ob:get_pos(), "windstorm:duster")
					end
				end
				windstorm.new_dust=nil
			end
		end
	end
end

windstorm.visibility=function(pos1,pos2)
	if not (pos2 and pos2.x and pos1 and pos1.x) then return nil end
	local v = {x = pos1.x - pos2.x, y = pos1.y - pos2.y-1, z = pos1.z - pos2.z}
	v.y=v.y-1
	local amount = (v.x ^ 2 + v.y ^ 2 + v.z ^ 2) ^ 0.5
	local d=math.sqrt((pos1.x-pos2.x)*(pos1.x-pos2.x) + (pos1.y-pos2.y)*(pos1.y-pos2.y)+(pos1.z-pos2.z)*(pos1.z-pos2.z))
	v.x = (v.x  / amount)*-1
	v.y = (v.y  / amount)*-1
	v.z = (v.z  / amount)*-1
	for i=1,d,1 do
		local node=minetest.get_node({x=pos1.x+(v.x*i),y=pos1.y+(v.y*i),z=pos1.z+(v.z*i)})
		if node and node.name and minetest.registered_nodes[node.name] and minetest.registered_nodes[node.name].walkable then
			return false
		end
	end
	return true
end