# afterearth

Licenses: code: LGPL-2.1, media: CC BY-SA-4.0

Version: 2r

The earth's ecosystem has collapsed, and there ain't no biologically environment left.
And the planet has become a difficult place to live on.

The only way to survive is to look around in trash for food and stuff, you have to eat everyting eatable, like grass and leaves and flowers.
Not even the water from lakes is longer drinkable, it is more like death traps.

The extreme temperature differences makes stone and sand in sunshine is too hot to touch at all
And the sunshine is far too power at afternoon 13:00 - 14:00

Unpredictable weathers can suddenly turn to storm, and can push away blocks, mobs, players and stuff.

Heavy gas accumulated at low ground, with makes it hard to breathe and dangerous to mine in underground
Plastic bags can be used to breathe inside
(use empty bags to fill with air, use in suffocating nodes to breathe)
You can also put stuff in a placed, burn with them, or craft 9 empty to a block




