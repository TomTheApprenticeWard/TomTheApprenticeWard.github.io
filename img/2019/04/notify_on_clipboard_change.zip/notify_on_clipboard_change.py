#!/usr/bin/env python

# sox needs to be installed: sudo apt install sox
# this script only works with python 2

import gtk
import os
import sys

class ClipboardParse:
    def __init__(self):
        self.clipboard = gtk.Clipboard()
        self.clipboard.connect("owner-change", self.NotifyOfClipboardChange)

    def NotifyOfClipboardChange(self, clipboard, event):
        print("clipboard changed")
        os.system("play " + sys.path[0] + "/assets/274001__junggle__water-drop-01.wav")
        return False

if __name__ == '__main__':
    ClipboardParse()
    gtk.main()