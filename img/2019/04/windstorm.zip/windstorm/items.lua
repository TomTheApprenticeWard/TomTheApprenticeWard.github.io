windstorm.spawn_dust=function(pos)
		if not (pos and windstorm.storm.dir and minetest.is_protected(pos,"")==false) then return end
		local drop=minetest.get_node_drops(minetest.get_node(pos).name)[1]
		local n=minetest.registered_nodes[minetest.get_node(pos).name]
		if not (n and n.walkable) or drop=="" or type(drop)~="string" then return end
		local t=n.tiles
		if not t[1] then return end
		local tx={}
		local tt={}
		tt.t1=t[1]
		tt.t2=t[1]
		tt.t3=t[1]

		if t[2] then tt.t2=t[2] tt.t3=t[2] end
		if t[3] and t[3].name then tt.t3=t[3].name
		elseif t[3] then tt.t3=t[3]
		end
		if type(tt.t3)=="table" then return end
		tx[1]=tt.t1
		tx[2]=tt.t2
		tx[3]=tt.t3
		tx[4]=tt.t3
		tx[5]=tt.t3
		tx[6]=tt.t3
	windstorm.new_dust={t=tx,drop=drop}
	local e=minetest.add_entity(pos, "windstorm:dust")
	e:set_velocity({x=windstorm.storm.dir.x*5, y=2, z=windstorm.storm.dir.z*5})
	e:set_acceleration({x=windstorm.storm.dir.x*5, y=-1, z=windstorm.storm.dir.z*5})
	windstorm.new_dust=nil
	minetest.remove_node(pos)
end

minetest.register_entity("windstorm:duster",{
	hp_max = 1000,
	physical =true,
	weight = 0,
	collisionbox = {-0.1,-0.1,-0.1,0.1,0.1,0.1},
	visual = "sprite",
	visual_size = {x=1,y=1},
	pointable=false,
	textures ={"windstorm_air.png"},
	spritediv = {x=1, y=1},
	initial_sprite_basepos = {x=0, y=0},
	is_visible = true,
	makes_footstep_sound = false,
	on_activate=function(self, staticdata)
		if not (windstorm.new_dust and windstorm.storm.dir) then
			self.object:remove()
			return self
		end
		self.d=windstorm.storm.dir
		return self
	end,
	on_step=function(self, dtime)
		self.time=self.time+dtime
		self.time2=self.time2+dtime
		if self.time2<0.1 then return self end
		self.time2=0
		local pos=self.object:get_pos()
		local pos2={x=pos.x+self.d.x,y=pos.y,z=pos.z+self.d.z}
		local u=minetest.registered_nodes[minetest.get_node(pos2).name]
		if not self.atta and u and u.walkable and minetest.get_item_group(u.name,"cracky")==0 and not minetest.is_protected(pos2,"") then
			windstorm.spawn_dust(pos2)
			self.object:remove()
		elseif self.time>3 or u and u.walkable then
			self.object:remove()
		elseif self.atta then
			local v=self.object:get_velocity()
			local pos2={x=pos.x+self.d.x,y=pos.y-1,z=pos.z+self.d.z}
			local u2=minetest.registered_nodes[minetest.get_node(pos2).name]
			if (u2 and u2.walkable) or (v.x+v.z==0) then
				self.atta:punch(self.atta,4,{full_punch_interval=1,damage_groups={fleshy=4}})
				self.object:remove()
				return self
			end
		elseif not self.atta then
			for i, ob in pairs(minetest.get_objects_inside_radius(pos, 1)) do
				if not (ob:get_luaentity() and ob:get_luaentity().dust) then
					self.object:move_to({x=pos.x,y=pos.y+1,z=pos.z})
					self.object:set_properties({collisionbox={-0.5,-0.5,-0.5,0.5,0.5,0.5}})
					ob:set_attach(self.object, "",{x = 0, y = 0, z = 0}, {x = 0, y =0, z = 0})
					self.atta=ob
					self.time=-30
					self.object:set_velocity({x=self.d.x*15, y=1, z=self.d.z*15})
					self.object:set_acceleration({x=0, y=-0.2, z=0})
					return self
				end
			end

		end
		return self
	end,
	time=0,
	time2=0,
	dust=1,
})

minetest.register_entity("windstorm:dust",{
	hp_max = 1000,
	physical =true,
	weight = 0,
	collisionbox = {-0.5,-0.5,-0.5,0.5,0.5,0.5},
	visual = "cube",
	visual_size = {x=1,y=1},
	textures ={"air.png"},
	spritediv = {x=1, y=1},
	initial_sprite_basepos = {x=0, y=0},
	is_visible = true,
	makes_footstep_sound = true,
	on_punch2=function(self)
		minetest.add_item(self.object:get_pos(),self.drop)
		self.object:remove()
		return self
	end,
	on_activate=function(self, staticdata)
		if not (windstorm.new_dust and windstorm.storm.dir) then self.object:remove() return self end
		self.drop=windstorm.new_dust.drop
		self.object:set_properties({textures = windstorm.new_dust.t})
		self.d=windstorm.storm.dir
		return self
	end,
	on_step=function(self, dtime)
		self.time=self.time+dtime
		if self.time<self.timer then return self end
		self.time=0
		self.timer2=self.timer2-1
		local pos=self.object:get_pos()
		local u=minetest.registered_nodes[minetest.get_node({x=pos.x,y=pos.y-1,z=pos.z}).name]
		for i, ob in pairs(minetest.get_objects_inside_radius({x=pos.x+self.d.x,y=pos.y-1,z=pos.z+self.d.z}, 2)) do
			if not (ob:get_luaentity() and ob:get_luaentity().dust) then
				ob:punch(ob,9,{full_punch_interval=1,damage_groups={fleshy=9}})
				break
			end
		end
		if u and u.walkable then
			local n=minetest.registered_nodes[minetest.get_node(pos).name]
			if n and n.buildable_to and minetest.registered_nodes[self.drop] then
				minetest.set_node(pos,{name=self.drop})
				self.object:remove()
			else
				self.on_punch2(self)
			end
			return self
		elseif self.timer2<0 then
			self.on_punch2(self)
		end
		return self
	end,
	time=0,
	timer=2,
	timer2=10,
	dust=1,
})
